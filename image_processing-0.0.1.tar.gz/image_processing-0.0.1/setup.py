from setuptools import setup, find_packages

with open("README.md", "r") as f:
    page_description = f.read()

with open("requirements.txt") as f:
    requirements = f.read().splitlines()

setup(
    name="image_processing",
    version="0.0.1",
    author="Ana Carolina",
    author_email="anacarolgbn@hotmail.com",
    description="image Processing Package using Python",
    long_description=page_description,
    long_description_content_type="text/markdown",
    url="https://github.com/carolgbn/criacao-de-pacotes-de-processamento-de-imagens-em-Python",
    packages=find_packages(),
    install_requires=requirements,
    python_requires='>=3.5',
)